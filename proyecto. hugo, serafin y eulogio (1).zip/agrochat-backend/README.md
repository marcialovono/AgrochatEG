# AgroChat GE — Backend Java + Spring Boot

## Estructura del proyecto

```
agrochat-backend/
├── pom.xml
└── src/main/
    ├── java/com/agrochat/
    │   ├── AgroChatApplication.java       ← Punto de entrada
    │   ├── controller/
    │   │   └── ChatController.java        ← Los 3 endpoints REST
    │   ├── service/
    │   │   └── GeminiService.java         ← Integración con Gemini API
    │   └── model/
    │       ├── ChatRequest.java
    │       ├── ChatResponse.java
    │       ├── ImageRequest.java
    │       └── ClimaRequest.java
    └── resources/
        └── application.properties         ← Configuración + API key
```

---

## Requisitos previos

| Herramienta | Versión mínima |
|-------------|---------------|
| Java JDK    | 17            |
| Maven       | 3.8+          |

---

## Paso 1 — Obtener tu API Key de Gemini

1. Ve a https://aistudio.google.com/app/apikey
2. Crea un proyecto o usa uno existente
3. Copia la API Key generada
4. Pégala en `src/main/resources/application.properties`:

```properties
gemini.api.key=TU_CLAVE_AQUI
```

---

## Paso 2 — Compilar y arrancar

```bash
# Desde la carpeta agrochat-backend/
mvn spring-boot:run
```

Verás en consola:
```
✅ AgroChat GE Backend iniciado en http://localhost:8080
```

---

## Paso 3 — Verificar que funciona

Abre en el navegador:
```
http://localhost:8080/api/health
```
Debe responder: `AgroChat GE Backend ✅ funcionando`

---

## Endpoints disponibles

### `POST /api/chat`
```json
{ "mensaje": "¿Cuáles son las plagas del cacao?", "cultivo": "cacao" }
```

### `POST /api/analizar-imagen`
```json
{ "imagen": "<base64>", "cultivo": "cacao", "mensaje": "Hojas amarillas" }
```

### `POST /api/analizar-clima`
```json
{
  "cultivo": "cacao",
  "zona": "Litoral",
  "temp": "28",
  "lluvia": "150",
  "humedad": "75",
  "meses": "6"
}
```

### `GET /api/health`
Health check del servidor.

---

## Solución de problemas

| Error | Causa | Solución |
|-------|-------|----------|
| `400 Bad Request` de Gemini | API Key inválida | Verifica la clave en `application.properties` |
| `CORS error` en el navegador | Petición bloqueada | Está permitido (`@CrossOrigin("*")`), recarga el HTML |
| Puerto 8080 ocupado | Otro proceso | Cambia `server.port=8081` en `application.properties` y actualiza la URL en el HTML |
| Imagen no analizada | Foto muy grande | El HTML ya convierte a base64; verifica que sea < 4MB |

---

## Seguridad (producción)

> Cuando publiques en producción, mueve la API key a una variable de entorno:
> ```bash
> export GEMINI_API_KEY=tu_clave
> ```
> Y en `application.properties`:
> ```properties
> gemini.api.key=${GEMINI_API_KEY}
> ```
