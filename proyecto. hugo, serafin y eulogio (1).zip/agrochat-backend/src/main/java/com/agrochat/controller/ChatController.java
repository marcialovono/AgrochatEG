package com.agrochat.controller;

import com.agrochat.model.*;
import com.agrochat.service.GeminiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Expone los 3 endpoints que consume el frontend AgroChat GE.
 *
 * Rutas:
 *   POST /api/chat              → chatbot general
 *   POST /api/analizar-imagen   → diagnóstico de plaga via foto
 *   POST /api/analizar-clima    → predicción de cosecha
 */

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")  // Permite peticiones desde el HTML local o cualquier origen
public class ChatController {

    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    private final GeminiService geminiService;

    public ChatController(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    // ─────────────────────────────────────────────────────────────
    // 1. Chat general
    //    Body: { "mensaje": "¿...", "cultivo": "cacao" }
    // ─────────────────────────────────────────────────────────────
    @PostMapping("/chat")
    public ResponseEntity<ChatResponse> chat(@RequestBody ChatRequest req) {
        log.info("[chat] cultivo={} mensaje={}", req.cultivo, req.mensaje);
        String respuesta = geminiService.chat(req.mensaje, req.cultivo);
        return ResponseEntity.ok(new ChatResponse(respuesta));
    }

    // ─────────────────────────────────────────────────────────────
    // 2. Análisis de imagen (diagnóstico de plagas)
    //    Body: { "imagen": "<base64>", "cultivo": "cacao", "mensaje": "..." }
    // ─────────────────────────────────────────────────────────────
    @PostMapping("/analizar-imagen")
    public ResponseEntity<ChatResponse> analizarImagen(@RequestBody ImageRequest req) {
        log.info("[imagen] cultivo={} imagenSize={}chars", req.cultivo,
                 req.imagen != null ? req.imagen.length() : 0);
        String respuesta = geminiService.analizarImagen(req.imagen, req.cultivo, req.mensaje);
        return ResponseEntity.ok(new ChatResponse(respuesta));
    }

    // ─────────────────────────────────────────────────────────────
    // 3. Análisis climático (predicción de cosecha)
    //    Body: { "temp":"28", "lluvia":"150", "humedad":"75",
    //            "meses":"6", "zona":"Litoral", "cultivo":"cacao" }
    // ─────────────────────────────────────────────────────────────
    @PostMapping("/analizar-clima")
    public ResponseEntity<ChatResponse> analizarClima(@RequestBody ClimaRequest req) {
        log.info("[clima] cultivo={} zona={} temp={}°C lluvia={}mm",
                 req.cultivo, req.zona, req.temp, req.lluvia);
        String respuesta = geminiService.analizarClima(req);
        return ResponseEntity.ok(new ChatResponse(respuesta));
    }

    // ─────────────────────────────────────────────────────────────
    // Health check (opcional, útil para verificar que el server corre)
    // ─────────────────────────────────────────────────────────────
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("AgroChat GE Backend ✅ funcionando");
    }
}
