package com.agrochat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroChatApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgroChatApplication.class, args);
        System.out.println("\n✅ AgroChat GE Backend iniciado en http://localhost:8080\n");
    }
}
