package com.agrochat.model;

public class ChatRequest {
    public String mensaje;
    public String cultivo;
}
