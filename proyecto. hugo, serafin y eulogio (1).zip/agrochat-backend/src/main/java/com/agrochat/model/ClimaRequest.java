package com.agrochat.model;

public class ClimaRequest {
    public String type;
    public String temp;
    public String lluvia;
    public String humedad;
    public String meses;
    public String zona;
    public String cultivo;
}
