package com.agrochat.model;

public class ChatResponse {
    public String respuesta;
    public ChatResponse(String respuesta) {
        this.respuesta = respuesta;
    }
}
