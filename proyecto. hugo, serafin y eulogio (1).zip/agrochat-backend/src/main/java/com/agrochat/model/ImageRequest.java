package com.agrochat.model;

public class ImageRequest {
    public String imagen;    // base64 del JPG/PNG
    public String cultivo;
    public String mensaje;   // texto adicional del usuario
}
