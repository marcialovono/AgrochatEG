package com.agrochat.service;

import com.agrochat.model.ClimaRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GeminiService {

    private static final Logger log = LoggerFactory.getLogger(GeminiService.class);

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();

    // ─────────────────────────────────────────────────────────────
    // Contexto base: quien es el asistente
    // ─────────────────────────────────────────────────────────────
    private static final String SYSTEM_CONTEXT = """
        Eres AgroChat GE, un asistente agrícola especializado en Guinea Ecuatorial.
        Tu rol es ayudar a agricultores locales con:
        - Diagnóstico de plagas y enfermedades en cultivos
        - Predicción de cosechas según condiciones climáticas
        - Consejos de manejo agrícola adaptados a la región
        
        Cultivos principales en Guinea Ecuatorial: cacao, café, yuca, plátano, maíz.
        Responde siempre en español, de forma clara y práctica.
        Usa emojis agrícolas cuando sea adecuado para hacer la respuesta más visual.
        Sé conciso: máximo 250 palabras por respuesta.
        Si no sabes algo con certeza, dilo honestamente.
        """;

    // ─────────────────────────────────────────────────────────────
    // 1. CHAT GENERAL
    // ─────────────────────────────────────────────────────────────
    public String chat(String mensaje, String cultivo) {
        String prompt = String.format("""
            %s
            
            El agricultor trabaja principalmente con: %s
            Pregunta del agricultor: %s
            """, SYSTEM_CONTEXT, cultivo, mensaje);

        return llamarGemini(prompt, null, null);
    }

    // ─────────────────────────────────────────────────────────────
    // 2. ANÁLISIS DE IMAGEN (detección de plagas)
    // ─────────────────────────────────────────────────────────────
    public String analizarImagen(String base64Image, String cultivo, String mensajeAdicional) {
        String promptTexto = String.format("""
            %s
            
            El agricultor ha subido una foto de su cultivo de %s.
            Mensaje adicional del agricultor: "%s"
            
            Analiza la imagen y responde:
            1. 🔍 **Diagnóstico**: ¿Qué problema detectas? (plaga, enfermedad, deficiencia nutricional, etc.)
            2. ⚠️ **Gravedad**: Leve / Moderada / Grave
            3. 🛡️ **Tratamiento recomendado**: Pasos concretos a seguir
            4. 💡 **Prevención**: Cómo evitarlo en el futuro
            
            Si la imagen no muestra un cultivo o problema claro, indícalo amablemente.
            """,
            SYSTEM_CONTEXT, cultivo,
            (mensajeAdicional != null && !mensajeAdicional.isBlank()) ? mensajeAdicional : "ninguno");

        return llamarGemini(promptTexto, base64Image, "image/jpeg");
    }

    // ─────────────────────────────────────────────────────────────
    // 3. ANÁLISIS CLIMÁTICO (predicción de cosecha)
    // ─────────────────────────────────────────────────────────────
    public String analizarClima(ClimaRequest data) {
        String prompt = String.format("""
            %s
            
            El agricultor proporciona los siguientes datos climáticos de su zona:
            - Cultivo: %s
            - Zona / Región: %s
            - Temperatura actual: %s°C
            - Precipitación: %s mm/mes
            - Humedad relativa: %s%%
            - Meses desde la siembra: %s
            
            Con base en estos datos, proporciona:
            1. 🌡️ **Evaluación del clima**: ¿Es adecuado para el cultivo en esta zona de Guinea Ecuatorial?
            2. 📅 **Predicción de cosecha**: Estimación del tiempo restante y rendimiento esperado
            3. ⚡ **Riesgos actuales**: Condiciones que podrían afectar la cosecha
            4. ✅ **Acciones recomendadas**: Qué debe hacer el agricultor ahora mismo
            
            Basa tu respuesta en el conocimiento del clima tropical de Guinea Ecuatorial.
            """,
            SYSTEM_CONTEXT,
            data.cultivo, data.zona, data.temp, data.lluvia,
            (data.humedad != null && !data.humedad.isBlank()) ? data.humedad : "no indicada",
            (data.meses != null && !data.meses.isBlank()) ? data.meses : "no indicado");

        return llamarGemini(prompt, null, null);
    }

    // ─────────────────────────────────────────────────────────────
    // Llamada HTTP a Gemini REST API
    // ─────────────────────────────────────────────────────────────
    private String llamarGemini(String promptTexto, String base64Image, String mimeType) {
        try {
            // Construir el body JSON
            ObjectNode body = mapper.createObjectNode();
            ArrayNode contents = body.putArray("contents");
            ObjectNode content = contents.addObject();
            ArrayNode parts = content.putArray("parts");

            // Parte de imagen (si existe)
            if (base64Image != null && !base64Image.isBlank()) {
                ObjectNode imgPart = parts.addObject();
                ObjectNode inlineData = imgPart.putObject("inlineData");
                inlineData.put("mimeType", mimeType != null ? mimeType : "image/jpeg");
                inlineData.put("data", base64Image);
            }

            // Parte de texto (siempre)
            ObjectNode textPart = parts.addObject();
            textPart.put("text", promptTexto);

            // Configuración de generación
            ObjectNode genConfig = body.putObject("generationConfig");
            genConfig.put("temperature", 0.7);
            genConfig.put("maxOutputTokens", 1024);
            genConfig.put("topP", 0.9);

            // Cabeceras HTTP
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            String url = apiUrl + "?key=" + apiKey;
            HttpEntity<String> entity = new HttpEntity<>(mapper.writeValueAsString(body), headers);

            log.info("Llamando a Gemini API...");
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

            // Extraer texto de la respuesta
            JsonNode respJson = mapper.readTree(response.getBody());
            return respJson
                .path("candidates").get(0)
                .path("content")
                .path("parts").get(0)
                .path("text").asText("No se pudo obtener respuesta.");

        } catch (Exception e) {
            log.error("Error llamando a Gemini API: {}", e.getMessage());
            return "⚠️ Error al consultar el asistente: " + e.getMessage();
        }
    }
}
